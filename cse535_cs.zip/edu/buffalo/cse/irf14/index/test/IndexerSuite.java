package edu.buffalo.cse.irf14.index.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({IndexerTest.class})
public class IndexerSuite {

}
